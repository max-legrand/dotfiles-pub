# Earle Mono — Bold & Bold Italic (added)

Two new faces to complete the RIBBI family (Regular / Italic / **Bold** / **Bold Italic**).

## How they were made (honest)
- **Synthetic, not redrawn.** Bold = algorithmic outline expansion of the single
  source weight (FontForge `changeWeight`, LCG, **squish** counters, +47 units on the
  1024 UPM). Bold Italic = that bold put through the *exact same* baseline shear used
  for the existing Italic (`x' = x + tan(12°)·y`), so Bold:BoldItalic relates to the
  family identically to Regular:Italic. This is the same class of synthetic face the
  Italic already is — not a hand-cut bold.
- **Weight:** stem 123 -> 170 units (~1.38x the Regular). Reads as a true bold without
  muddying counters at display sizes.
- **Squish emboldening** grows weight *into the counters*, so glyphs do not widen past
  the cell. All ASCII glyphs stay inside the 886 cell (max xMax 862, 0 overflow) and
  every advance is exactly 886 — monospace is preserved.

## Verified at the binary level (fontTools)
- Advance width = 886 on all 341 glyphs (both faces). Glyph set & cmap match Regular.
- UPM 1024. Vertical metrics (typo 819/-205/307, hhea 819/-205/307, win 1321/332) and
  the USE_TYPO_METRICS flag are copied verbatim from Regular -> line height is identical
  across all four faces.
- Style bits for native style-linking: Bold fsSelection 0xA0 / macStyle 1 / usWeightClass
  700; Bold Italic fsSelection 0xA1 / macStyle 3 / italicAngle -12 / usWeightClass 700.
  Family name "Earle Mono" shared across all four; subfamilies Regular/Bold/Italic/Bold Italic.

## NOT verified — test before relying on it
- **Real rendering at your coding size on your OS.** Hinting is inherited from the source
  (same caveat as the rest of v0.1); small-size Windows/ClearType behavior of the bolder
  stems has NOT been checked on a real screen. Install and look at your actual px size
  before adopting.
- Taste: this is a faithful synthetic bold, not a drawn one. If you later draw a true
  bold master, these are a drop-in placeholder until then.

## Version
Internal name/version left at "Version 0.1" to match the existing files. Bump the whole
family when you cut the next release.
