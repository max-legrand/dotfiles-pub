# Los Alamos Mono / TX-52 public references

## Primary sources

1. **USGC / @usgraphics announcement, 2024-04-27**  
   https://x.com/usgraphics/status/1784230999196590284  
   Original image: https://pbs.twimg.com/media/GMLbShrbcAA9ith.jpg?name=orig  
   Text identifies **TX-52 Los Alamos Mono™**, described as “A hyperbrutal typeface for critical code and elevated risk applications, exclusively engineered for ultra-high conspicuity by US Graphics.” The post said “Coming soon, 2024”; this is a historical announcement, not proof of present availability.

2. **USGC / @usgraphics comparison with OCR-B, 2026-02-17**  
   https://x.com/usgraphics/status/2023821586533675175  
   Original image: https://pbs.twimg.com/media/HBYNI_naUAAxxpl.jpg?name=orig  
   Los Alamos Mono is on the **left**, OCR-B on the **right**. Author warns that sizes differ and there are alignment mistakes. Author emphasizes fitting differences and readability of “Electrical” and “Breaker”. Do not treat OCR-B's right-hand shapes as TX-52 or use this as a calibrated metric comparison.

3. **IP over Thunderbolt 4 terminal screenshot, 2024-04-26**  
   https://x.com/usgraphics/status/1783966889892626570  
   Original image: https://pbs.twimg.com/media/GMHr1DZaQAAV35B.jpg?name=orig  
   The announcement explicitly identifies the font in this test as TX-52. Useful additional lowercase, number, and punctuation sample.

4. **OCR-B print context, 2026-02-17**  
   https://x.com/usgraphics/status/2023821583585079730  
   Describes Zebra ZT610 built-in OCR-B, Font E, 600 dpi scan, Z-Select 2000 paper tag, Zebra 3200 resin/wax ribbon. Context for source 2, **not a TX-52 specimen itself**.

5. **Official product index**  
   https://usgraphics.com/products  
   Search index lists Berkeley Mono, Houston Mono, and Los Alamos Mono. Direct site access returned Cloudflare HTTP 403 here. Exact Los Alamos product route and current release status were not verified.

## Visual evidence and limits

The original images for sources 1 and 2 were downloaded and visually inspected. Source 1 is a clean green-on-black uppercase/numeric specimen. Source 2 adds lowercase in a scanned receipt.

- Source 1 has a monoline, narrow/tall industrial monospaced appearance, generous space between glyph bodies, flat stroke ends, and smooth curves. It is not a pixel/bitmap design and not an all-square circuit-board design.
- Uppercase `I` has short horizontal bars at top and bottom. `M` has straight vertical sides with diagonals meeting partway down. `R` has a rounded bowl and diagonal leg. `A` has a pointed top and low horizontal crossbar. `G` has a short inward horizontal bar.
- Numeral `1` has an angled upper flag and no broad baseline foot. `4` is open at the top. `7` has no middle crossbar and a slightly curved descending stroke. `0` is an unmarked rounded rectangular/oval shape in this specimen; do not invent a slash or dot as a source-matched default. `O` is also unmarked; their relative dimensions need measurement before claiming an exact distinction.
- Period is a square-like block; comma has a strong diagonal tail. Slash is long and straight.
- Source 2 shows readable lowercase at smaller sizes. Its rough print edges must not be copied as outline roughness. Character fitting differs from OCR-B.
- Screenshots do not establish exact outlines, units-per-em, spacing metrics, complete glyph coverage, weight range, italics, kerning, or licensing. Any reconstructed font should clearly be described as an independent approximation, not the original TX-52.

## Retrieval notes

The websearch skill was read and attempted, but no Serper API key is configured. Bing public HTML provided the initial X links. The full public post text, dates, and image URLs were then verified through Twitter's syndication endpoint:

- https://cdn.syndication.twimg.com/tweet-result?id=1784230999196590284&token=0
- https://cdn.syndication.twimg.com/tweet-result?id=2023821586533675175&token=0

Temporary inspected originals: `/tmp/lam-reference-0.jpg` (announcement), `/tmp/lam-reference-1.jpg` (comparison).

Search results also include **Los Alamos by Steve Jackaman / Red Rooster**, a different decorative family. It is unrelated to USGC TX-52 and must not be used as a source. Unverified third-party “free download” listings are not evidence of authenticity or permission.
