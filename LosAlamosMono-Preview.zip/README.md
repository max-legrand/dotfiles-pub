# Los Alamos Mono — v2.720 (private study build)

**Unofficial reconstruction for private study. Not the official TX-52 Los Alamos
Mono, not affiliated with US Graphics / Berkeley Graphics, and not for
redistribution.** Buy the real font when it ships.

## What v2.720 is

A hybrid, chosen by measurement rather than preference:

- **Letterforms** come from the TX-52 sources that measured closest to your
  samples — banner vector artwork for capitals and digits, raster-recovered
  `K V 9 , /`, and the sample-measured lowercase redraws.
- **Punctuation** comes from the OCR-B master, cap-normalized (`H` 890 → 700) so
  it sits correctly against these capitals, except where the artwork itself
  supplies it (`.` `:` `,` `#` `+` `-`).
- `%` and `&` are **recovered outlines** traced from the 28pt label row
  (cap 88.74 px) with the same cubic contour fitting used for `K V 9`.
  `$` uses a measured-proportion fit, which scored better than tracing it.
- `(` `)` and `/` `\\` keep the terminal-sample width, depth and cap-stem weight.
- `[ ] { } ( )` share one vertical extent (-130 to 770). The intro specimen
  shows all six delimiters at the same height (107 px at cap 97), so brackets
  and braces are matched to the measured parentheses. A test enforces this.

## Measured match to the supplied samples

Per-glyph ink overlap against the two large label rows, cap-matched and
ink-centred, so it scores shape rather than tracking:

| Build | Mean | Median | Digits | Punctuation |
| --- | ---: | ---: | ---: | ---: |
| **v2.720 hybrid + recovered symbols (current)** | **0.922** | **0.943** | **0.932** | **0.904** |
| v2.600 hybrid | 0.889 | 0.942 | 0.932 | 0.774 |
| v2.500 OCR-B-only | 0.808 | 0.816 | 0.845 | 0.692 |
| v2.300 vector-derived | 0.884 | 0.942 | 0.932 | 0.757 |
| OCR-B master, unmodified | 0.730 | 0.740 | 0.732 | 0.689 |

v2.720 keeps v2.300's letterform accuracy and beats every previous build on
punctuation. Caveat: 35 glyph instances, dominated by digits; only two lowercase
and two uppercase instances. The terminal rows were excluded because column
segmentation was unreliable, so this is not a whole-alphabet verdict.
`0` scores 0.808 only because of the requested slash; the sampled zero is
unmarked and `cv01` renders that form. `&` (0.702) is the most complex glyph in
the set and loses interior detail when traced at 88 px cap.

## Structure

- Fixed advances (604 Preview, 450 UltraCompressed). **No kerning, no
  ligatures** — terminal columns cannot shift.
- Paired punctuation is drawn once and mirrored, so `( )`, `[ ]`, `{ }`,
  `< >`, `/ \\` cannot drift apart.
- Slashed zero by default; `cv01` restores the artwork's unmarked zero.
- Bold is an offset expansion, italics are 8° obliques. Neither appears in any
  source.

## Build and validate

```sh
uv run python build.py && uv run python test_fonts.py
uv run python render.py && uv run python package.py
```

`test_fonts.py` checks, for all 8 fonts: ASCII coverage, fixed advances, style
linking, vertical/cell bounds, source-to-compiled outline agreement (<2% mask
error, one threshold for every character), **compiled** pair-mirror symmetry,
HarfBuzz shaping proving fixed cells and no ligature substitution, and `cv01`.

`archive/v2.300/` holds the previous hand-patched build.
