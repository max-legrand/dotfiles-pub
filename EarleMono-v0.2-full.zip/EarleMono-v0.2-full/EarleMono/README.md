# Earle Mono v0.1 — an OCR-B reworked for code

A monospaced programming font derived from the free, OFL-licensed digitization of
**OCR-B** (Adrian Frutiger, 1968; digitized by Raisty). Named after **Naval Weapons
Station Earle** (Mainside in Howell / Colts Neck, NJ) — the U.S. Navy ordnance base
named for Rear Admiral Ralph Earle, WWI chief of the Bureau of Ordnance. The rename
keeps the US-engineering lineage and also satisfies the OFL Reserved Font Name rule:
"OCR-B" may not be reused by a modified version.

This is a **starting base (v0.1)**, not a finished typeface and not a substitute
for US Graphics' forthcoming Los Alamos Mono. It modifies existing outlines; it
does not redraw glyphs.

## What was changed from stock OCR-B
- **True monospace.** Stock OCR-B let 16 glyphs drift off the 886-unit cell
  (884 / 782 / 1150, plus two double-width). All advances forced to one width so
  columns never misalign in an editor or terminal.
- **Dotted zero.** A centered dot was added to `0` so it can never be confused
  with `O` — the single most important fix for reading code.
- **Unified vertical metrics.** Stock OCR-B disagreed across hhea / typo / win
  (1319 vs 819 vs 1321), so line height changed between editors. Now harmonized
  to a consistent ~1.30em with the USE_TYPO_METRICS flag set.
- **Italic.** A 12-degree oblique companion (synthetic, see limits below).
- **Renamed & relicensed notice** for OFL compliance.

## Honest limitations (v0.1)
- **No true bold.** Only the single source weight exists. Real bold needs outline
  expansion/redrawing. Most editors will synthesize a faux-bold meanwhile.
- **Italic is a shear, not a drawn italic.** It reads fine but isn't a true cut.
- **No programming ligatures** (`->`, `!=`, `>=`…). This is deliberate: OCR's
  whole philosophy is literal, unambiguous glyphs, and bad auto-ligatures are
  worse than none. To add them later, draw the ligature glyphs and wire a GSUB
  `calt`/`liga` feature with fontTools feaLib.
- **Hinting is inherited, not re-done.** Small sizes on Windows/ClearType may be
  imperfect — test at your real size before adopting (the same thing that soured
  Pragmata for you).
- **Character set = the source's** (≈341 glyphs: Latin + ASCII symbols). No
  Powerline/Nerd Font icons, limited non-Latin coverage.

## Files
- `EarleMono-Regular.ttf` / `EarleMono-Italic.ttf` — install these.
- `EarleMono-*.woff2` — for web/editor-in-browser use.
- `OFL.txt` — license (original OCR-B OFL + modification notice).
- `specimen.png` — rendered proof.

## License
SIL Open Font License 1.1. You may use, modify, and redistribute under OFL terms.
Do not reuse the Reserved Font Name "OCR-B" for further modified versions.
