# Audit of the two new Los Alamos samples

Read-only source audit. The font sources and `dist/` were not changed.

## Scope and method

- `user-sample-1.png`: 1504 × 2000 px. Use the main horizontal numeric size rows, especially 28, 24, and 20. Only the 24 and 20 rows contain large useful `e/m` and periods.
- `user-sample-2.png`: 2000 × 1414 px. Use the green `system_profiler`/`sw_vers` text. Do not use the shell prompt's colored symbols.
- **Excluded:** test-label color-block `Aa`, icons, rotated text, barcodes, and the separate angular/OCR-like alphabet row at y≈1862. That alphabet has a different design and is not a lowercase measurement source. The footer is a secondary punctuation check only, not primary x-height evidence.
- Pixel coordinates below refer to the original images, not the resized chat previews. Crop rectangles are half-open.
- `measure_samples.py` makes hand-checked glyph crops. It saves threshold bboxes and continuous half-peak edge estimates to `sample-measurements.json`. Label masks use darkness thresholds 80/128/180. Terminal masks use green thresholds 45/65/85. Half-peak estimates interpolate edge crossings of the maximum-intensity projection.
- The terminal has colored antialiasing/fringes. Its raw 30-px `H` bbox is **not** a reliable 30-px cap height. The continuous cap is about 28.7–28.9 px. Whole-line bboxes also include above-cap `i/l/h`, parentheses/slashes, and descenders; they are not cap measurements.
- Flat `E/7` determine label cap/baseline. Flat `H/R/M/B` determine terminal cap/baseline. Lowercase round/arched tops are not nominal x-height. The current `m` reaches 529, although OS/2 x-height and flat `x` are 514.
- Uncertainty estimates below include antialiasing and unknown image resampling/aspect ratio, not merely the much smaller regression residual. At terminal size, a one-pixel error is about 24 cap-normalized font units. Do not interpret decimal outputs as design-unit precision.

Reproduce from project root:

```sh
uv run python references/ocrb-refresh/measure_samples.py
```

## Cap, x-height, and cells

### Label, main numeric rows

Repeated `2` occurs five cells apart. Measuring the same glyph at both positions removes sidebearing/ink-width bias. Pitch uses the two continuous ink centers divided by five.

| Row | Flat cap, px | Baseline image y | Cell pitch, px | Cell / cap | Advance at cap 700 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 28 | 88.74 | 677.61 | 78.51 | 0.8847 | 619.3 |
| 24 | 76.14 | 799.68 | 67.30 | 0.8839 | 618.7 |
| 20 | 63.48 | 905.63 | 56.08 | 0.8835 | 618.4 |

Practical estimate: **cell/cap 0.884 ± 0.008**, or **619 ± 6 at cap 700**. The font size labels are consistent with proportional scaling, but do not establish source UPM or application metrics.

| Glyph | Row 24, px width × height | Row 20, px width × height | Normalized finding |
| --- | ---: | ---: | --- |
| `m` | 56.49 × 57.16 | 47.20 × 47.86 | Width ≈520; arched top ≈525–528 |
| `e` | 51.49 × 58.19 | 43.00 × 48.70 | Width ≈474; total round bbox ≈535–537 |
| `.` | 19.84 × 20.09 | 16.65 × 16.99 | Width ≈183; height ≈186 |

The measured `m`/cap height ratio is 0.751–0.754. **Do not change x-height to 526 because of this.** The built `m` already has its arched top at 529, and its nominal x-height is 514. `e` has both top and bottom round overshoot. These large label glyphs support retaining the current lowercase scale.

### Terminal

The full line `Resolution: 5120 x 2880 (5K/UHD+ - Ultra High Definition Plus)` fits a fixed cell grid with pitch **25.7047 px**. The fit allows a separate ink-center offset per character, so `i`, `l`, parentheses, and wide letters do not bias pitch. Its center residual is only 0.022 px RMS, but this does not remove cap-edge/resampling uncertainty.

- Flat cap: **28.7–28.9 px**.
- Flat `x`: **21.34 px**, ratio **0.743** relative to same-line `H`.
- Rounded/arched `n/m` tops: **21.6 px**, ratio about **0.753**.
- Continuous terminal cell/cap: **0.895**, practical uncertainty about **±0.015**, or **626 ± 11 at cap 700**.
- Flat x-height inference: about **520 ± 15** at cap 700. **Current 514 is within the source's useful precision.**
- Main baseline pitch is about **47.45 px**, or 1.65 cap heights. This includes terminal line-spacing settings. It does not independently justify changing font ascender/descent metrics.

### Comparison with current widths

- Preview: `604/700 = 0.8629`. It is about 2.4% tighter than the main label and about 3.6% tighter than the terminal's continuous-edge estimate.
- UltraCompressed: `450/700 = 0.6429`. Neither new source demonstrates that compressed width; it remains an intentional project variant.
- The new samples support a source-proportion pitch around **620–625**, consistent with the existing banner-derived 621.687 estimate. They do not prove whether small differences arise from tracking or resampling.
- If source-proportion width is wanted, an explicit ≈622-unit option is defensible. Do not silently replace the user's 450-unit cut or claim either PNG proves exact original advance metadata.

## Baseline, ascenders, and descenders

Use nearby flat capitals to locate the baseline. Do not subtract `p`'s whole bbox from a global row bbox.

| Terminal feature | Measured cap-normalized units | Current Preview Regular | Finding |
| --- | ---: | ---: | --- |
| `h/l` top | ≈748–752 | 750 | Matches |
| `i/j` top | ≈775 | 772 | Matches |
| `p` bottom | ≈−179 | −190 | Within small-raster uncertainty |
| `g` bottom, two occurrences | ≈−196 | −190 | Matches within uncertainty |
| `y` bottom | ≈−188 | −182 | Matches within uncertainty |
| `j` bottom | ≈−173 | −172 | Strong match |

Allow roughly ±15–25 units for individual terminal extrema. **No new evidence supports deeper lowercase descenders or a changed nominal x-height.** The main label rows contain no lowercase descenders and cannot establish descender depth. The footer comma descends ≈165 units, agreeing with current −165, but it is not a `g/p/y` proxy.

## Punctuation: supported differences

The terminal's ordinary text gives repeated punctuation samples, with no need to use a logo or decorative glyph. Coordinates and exact half-peak estimates are in the JSON. Practical target ranges below are deliberately wider than the subpixel fit scatter.

### Parentheses — high-confidence mismatch

Four glyphs were checked: both in `Vendor: Apple (0x106b)` and both in the `Resolution` line.

- Width: **14.59–14.70 px**.
- Height: **36.90–37.00 px**.
- At cap 700: **width 355–357, height 896–900**.
- Top: **≈767–769** above baseline.
- Bottom: **≈−129 to −132**.
- Practical targets: **width 355 ± 20; top 770 ± 15; bottom −130 ± 20**.
- Both sides have essentially the same dimensions and are visibly curved. The opening parenthesis ink center is about 0.10 cell to the right of the paired-digit center; closing is about 0.10 cell left. Whole-font sidebearings still require a rendering check.

Current built Preview `(` and `)` are only **≈174 wide**, **772 high**, and have bottom **≈0**, entirely above the baseline. Ultra is ≈166 wide. These are not the source terminal proportions. The new sample directly supports **widening both parentheses and extending them below the baseline**, while keeping their top near 770. Do not merely stretch them upward.

### Slash — high-confidence mismatch

Both slashes are ordinary text: `Graphics/Displays` and `(5K/UHD+ - ...)`.

- Width: **17.91–17.97 px**.
- Height: **36.27–36.29 px**.
- At cap 700: **width 435–438; height 882–884; top 801–802; bottom ≈−82**.
- Practical targets: **width 437 ± 20; top 800 ± 20; bottom −82 ± 20**.

Current `/`: **368 wide**, bounds **−6 to 750**. The new normal-text sample supports a wider and taller slash, with a small descender. This conclusion does not use the unrelated large logo slash from earlier references.

### Dots, colon, hyphen, plus — retain current scale

| Item | New sample estimate at cap 700 | Current Preview | Interpretation |
| --- | ---: | ---: | --- |
| Label period | ≈183 × 186 | 180 × 181 | Strong agreement; ±5–8 units is realistic |
| Terminal period | ≈191 × 193 | 180 × 181 | Difference is <0.6 px; do not enlarge from this alone |
| Terminal colon dots | ≈190 × 193 | 180 × 181 | Same small-raster caveat |
| Colon total y bounds | ≈29 to 559 | 32 to 557 | Strong positional agreement |
| Terminal hyphen | ≈372 × 102; y≈265..367 | 362 × 88; y272..360 | Center matches; stroke-height difference <1 px |
| Terminal plus | ≈452 × 478; y≈79..557 | 444 × 476; y78..554 | Matches |
| Terminal `i` dot | ≈148 × 146 | Separate smaller dot | Do not replace it with the period dot |

The footer comma is approximately **346 × 341**, bottom ≈−165, compared with current ≈319 × 340, bottom −165. Its width is a lower-confidence discrepancy from a small secondary row. Keep the established comma geometry unless a larger same-font comma confirms a width change. No brackets, braces, semicolon, question mark, or exclamation mark in the primary new samples support a new shape recommendation.

## Supplied OCR-B font: calibration, not presumed identity

Measured from `upstream/dist/OCR-B.otf` (the supplied repository copy). `OS/2.sCapHeight` and `sxHeight` are zero; use actual outlines. `H` is 890 units high and the advance is 886 at 1024 UPM.

| OCR-B measure normalized using `H=700` | Value | New-source implication |
| --- | ---: | --- |
| Advance | ≈697 | Too wide relative to the ≈619–626 source cell |
| Flat `x` | ≈530 | Near, but slightly above current514; PNG precision does not demand replacing514 |
| `m` top | ≈537 | Current529 is already closer to label525–528 |
| `h` top | ≈766 | Current750 matches terminal better |
| Parenthesis width/height | ≈278 × 783 | Still narrower/shorter than terminal≈356 × 898 |
| Parenthesis bottom | ≈−15 | Terminal reaches≈−130 |
| Slash width/height | ≈422 × 777 | Width is closer; height still short against terminal≈883 |
| Period width/height | ≈220 × 178 | Too wide for label's near-square≈183 × 186 |

OCR-B can provide a comparison or drawing scaffold. A uniform cap normalization or blind replacement does **not** reproduce the new samples. In particular, do not inherit its advance or punctuation untouched. License/provenance review is separate from this image audit.

## Recommendations limited to these new samples

1. Keep cap 700, nominal x-height 514, existing lowercase overshoot, and existing lowercase descender depths.
2. Correct parentheses to about **355 wide, y−130..770** at cap700, subject to a final pixel overlay.
3. Correct ordinary slash to about **437 wide, y−82..800** at cap700, subject to a final pixel overlay.
4. Keep period/colon scale and the separate smaller `i/j` dots. Keep plus/hyphen positions. Do not infer changes for absent punctuation.
5. Treat **≈622-unit source pitch** as an optional source-proportion choice, not proof that the intentional604/450 families must both change.
6. The sources show unslashed zero. That observation does not override this project's separately requested slashed-zero default/unslashed alternate.

Audit artifacts: `sample-measurements.json`, `audit-font-metrics.json`, `measure_samples.py`, and `*-crop.png`. The font metrics file records the built fonts observed during this audit; source edits made later can differ.
