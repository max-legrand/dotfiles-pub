# Earle Mono — v0.2 (full)

> **Update:** Bold recut lighter (stem ~170, ~1.38× Regular, down from 1.55×) for better counter legibility; the squish-emboldened heavy weight was clogging `@ 8 a e g` at small sizes. Applies across all three families.

OCR-B reworked for code. This bundle has three families; pick one to install.
All are the same OFL-licensed design — they differ only in fit.

| Family                | Folder                | What it's for |
|-----------------------|-----------------------|---------------|
| **Earle Mono**        | `EarleMono/`          | The canonical design. Now a full 4-style RIBBI family (Regular / Italic / **Bold** / **Bold Italic**). Native cell is wide and large-on-the-body. |
| **Earle Mono Term**   | `EarleMono-Term/`     | Same letterforms, re-fitted so WezTerm needs **no `font_size` / `cell_width` overrides** (reproduces size 10 + cell_width 0.8 at WezTerm defaults). Wide glyphs overhang slightly. |
| **Earle Mono Term Clean** | `EarleMono-Term-Clean/` | Like Term, but glyphs condensed ~17% so upright styles don't overhang. ~17% narrower forms. |

Each family installs independently (distinct internal names) — they won't collide.

> **Update 2 — hinting + Euro fix (all 12 faces):**
> - **Autohinted** with ttfautohint 1.8.4 (fpgm/prep/cvt/gasp + per-glyph bytecode on every face, including the previously-unhinted synthetic bolds). Should improve small-size Windows/ClearType rendering — VERIFY on your own screen, since that's the rendering I can't see from here.
> - **Fixed Euro mapping**: the Euro glyph was mapped to U+20A0 (¤), so typing `€` (U+20AC) produced nothing. Now `€` resolves on every face; the incorrect U+20A0 mapping was removed.

> **Update 3 — slashed zero (all 12 faces):** the dotted zero was replaced with a slashed zero (the terminal/aerospace convention seen in Los Alamos Mono and many coding fonts — a generic convention, not anyone's IP). The slash is emboldened in the bolds, sheared to match the 12° italics, and scaled for Term/Term Clean. Earle's own oval shape is kept; only the dot→slash changed. Re-autohinted afterward so the new glyph is hinted on every face.

## Which should I use?
- General use / design fidelity → **Earle Mono**.
- WezTerm, want your dialed-in look with zero overrides, letterforms untouched → **Earle Mono Term**.
- WezTerm, want the same density with no wide-glyph overlap → **Earle Mono Term Clean**.

Term vs Term Clean is a real toss-up — install both and compare on your own screen
(see each folder's notes + proof PNGs). The difference: Term keeps OCR-B's width but
overlaps on m/w/M/W/K runs; Term Clean fixes the overlap at the cost of ~17% narrower forms.

## How the new pieces were made (honest)
- **Bold / Bold Italic**: synthetic — algorithmic outline expansion (squish counters,
  stem 123→170 ≈ 1.38x) and, for Bold Italic, the same 12° baseline shear as the existing
  Italic. Same class of synthetic face the Italic already is, not hand-drawn cuts.
- **Term / Term Clean**: uniform 10/12 downscale (cap height → a conventional 0.724 em)
  + advance set to 591 (= 886 × 0.8 × 10/12). Term keeps natural glyph widths; Term Clean
  condenses glyphs ~17% to fit. Both stay true monospace (advance 591), identical line
  height (1.083 em), USE_TYPO_METRICS set.

## Verified vs not
- Verified at the binary level: monospace advances, RIBBI style bits, glyph coverage,
  shared vertical metrics, and the geometry math (see per-folder notes).
- **NOT verified — test before committing:** all proofs are FreeType renders, not your
  live terminal/editor. Hinting is inherited from the source (small-size Windows/ClearType
  unchecked). The Term size anchor assumes WezTerm's default `font_size` is 12; if yours
  differs, the font is still conventionally sized — just use your usual number.

## Note
Font files still report internal version 0.1 to match the original release; the "v0.2"
is this bundle. Bump the internal version when you cut a real release.

## License
SIL Open Font License 1.1 (`OFL.txt`). Do not reuse the Reserved Font Name "OCR-B".
