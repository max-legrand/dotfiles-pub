# Earle Mono Term — size + cell-width baked in

A re-fitted cut of the family so WezTerm needs **no `font_size` or `cell_width`
overrides**. Separate family name ("Earle Mono Term") so it does NOT overwrite
your existing Earle Mono install.

## WezTerm config
```lua
config.font = wezterm.font 'Earle Mono Term'
-- leave font_size at the default (12.0) and cell_width at the default (1.0)
```
All four styles (Regular/Bold/Italic/Bold Italic) resolve from that one name.

## What changed and why (the honest version)
- **"Font size 10" cannot literally be stored in a font** — the app always picks
  point size. The *reason* you needed 10 was the body: cap height was 0.869 em where
  the convention is ~0.70. I uniformly scaled every face by 10/12, so cap height is
  now 0.724 em — conventionally sized. At the default size 12 it renders like your
  old size 10.
- **`cell_width 0.8` IS a real font property** (the advance width). Per WezTerm's docs,
  cell_width only narrows the advance and lets glyphs overhang — it does not reshape
  glyphs. I set the advance to 886 x 0.8 x 10/12 = **591 units**, reproducing your
  column pitch exactly at cell_width 1.0.
- Letterforms are unchanged (uniformly scaled, not distorted). Vertical metrics scaled
  to match (line height 1.300 -> 1.083 em), USE_TYPO_METRICS kept. Still true monospace
  (every advance = 591).

## Verified
- Geometry/math at the binary level: advance = 591 on all glyphs (4/4 faces),
  cap 0.724 em, advance:cap 0.797 == your current effective 0.796.
- The grid simulation (proof_equivalence.png) shows Term @ defaults == Original @
  (size 10, cell_width 0.8), pixel for pixel.

## VERIFY BEFORE RELYING ON THIS
- The proof is a FreeType render, NOT your live WezTerm. Install and eyeball it at your
  real DPI/hinting before committing.
- The size match assumes WezTerm's default `font_size` is **12.0**. If your usual size
  is different, the font is still conventionally sized — just set your usual number.
  The cell-width bake is exact regardless of size.
- The slight right-edge overhang on wide glyphs (m, w, y) is preserved *exactly* as in
  your current cell_width 0.8 setup — same pixels. If you'd rather have NO overhang, I
  can cut a truly condensed variant instead (narrower letterforms, WezTerm's recommended
  "stretch" approach) — but that changes the OCR-B letterform proportions.
