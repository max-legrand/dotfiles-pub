Ghostty for Windows — 1.3.0
https://github.com/shiweis/ghostty-windows

QUICK START
  1. Run ghostty.exe
  2. Config file: %LOCALAPPDATA%\ghostty\config.ghostty
     (the legacy filename "config" is also supported)

KEYBOARD SHORTCUTS
  Ctrl+Shift+T        New tab
  Ctrl+Shift+W        Close tab/pane
  Ctrl+Shift+N        New window
  Ctrl+Shift+P        Command palette
  Ctrl+Shift+O        Split right
  Ctrl+Shift+E        Split down
  Ctrl+Shift+[ / ]    Navigate splits
  Ctrl+Shift+C / V    Copy / Paste
  Ctrl+Shift+F        Find
  Ctrl+Enter          Toggle fullscreen
  Ctrl+= / - / 0      Zoom in / out / reset
  Ctrl+,              Open config file

SHELL INTEGRATION (PowerShell)
  Add to your PowerShell profile:
    . "$env:LOCALAPPDATA\ghostty\share\ghostty\shell-integration\powershell\ghostty-shell-integration.ps1"

For full documentation: https://ghostty.org/docs
