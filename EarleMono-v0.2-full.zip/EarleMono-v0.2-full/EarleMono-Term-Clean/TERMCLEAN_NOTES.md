# Earle Mono Term Clean

Same fit as "Earle Mono Term" (size baked to a conventional cap height; cell density
= your old cell_width 0.8), but the glyphs are condensed ~17% so they actually fit the
narrow cell instead of overhanging. Use whichever you prefer after testing both on your
own screen.

## WezTerm
```lua
config.font = wezterm.font 'Earle Mono Term Clean'
-- no font_size / cell_width overrides
```

## Term vs Term Clean
- **Term**: reproduces your cell_width 0.8 exactly — OCR-B letterforms 100% intact, but
  wide glyphs (m w M W @ K) overhang/overlap their neighbors, mildly in Regular and more
  visibly in Bold.
- **Term Clean**: glyphs condensed ~17% (advance unchanged at 591) so the upright styles
  no longer overlap — Regular is fully clean; Bold has a single glyph (K) that touches by
  ~4 units (imperceptible). Cost: letterforms are ~17% narrower, so the OCR roundness is
  slightly flattened. Same body size, same column pitch, same line height as Term.

## Italics — read this
Italic and Bold Italic still overhang the cell. That is intrinsic to the 12-degree
synthetic shear (tall glyphs lean past the right edge) and is present in your ORIGINAL
Italic at any cell width — it is NOT introduced or worsened here. The condense actually
reduces it somewhat. Only a redrawn (non-sheared) italic would remove it.

## Still true
- Monospace: every advance = 591. Four-style RIBBI family, native bold/italic linking.
- Vertical metrics identical to Earle Mono Term (line height 1.083 em). USE_TYPO_METRICS set.
- Separate family name — does not touch your existing Earle Mono or Earle Mono Term installs.

## VERIFY BEFORE COMMITTING
These are FreeType renders, not your live WezTerm. Install Term and Term Clean side by
side, look at real code at your DPI/size, and pick. The size anchor assumes WezTerm's
default font_size is 12; if yours differs the font is still conventionally sized — just
use your usual number.
