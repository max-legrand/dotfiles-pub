# Reference audit and vector extraction

## Usable assets
- `references/banner.svg`: authoritative outlined vector specimen, 600×600 viewBox.
  URL: https://usgraphics.com/static/products/TX-52/images/TX-52-banner.5ed48a4fb8e8.svg
  Linked by https://usgraphics.com/products (HTTP200 during this audit), under Los Alamos Mono / TX-52, marked Coming soon.
- `references/banner-large.png`: 1800×1800 render of that SVG.
- `references/vector_glyphs.json`: character → SVG path string. Coordinates are baseline-up, cap700, ink-centered on x302, intended advance604. No outline distortion; uniform scale700/32.643 and vertical inversion only. Paths obtained with fontTools SVG parser, SVGPathPen, TransformPen in project uv environment.
- `references/vector_glyphs_meta.json`: original path index/bounds, chosen baseline and transformed width/height.
- `references/banner-paths.json`: original white glyph paths, indices, exact Bézier bounds.
- `references/announcement-original.jpg`:1527×1527 https://pbs.twimg.com/media/GMLbShrbcAA9ith.jpg?name=orig
- `references/comparison-original.jpg`:2210×1308 https://pbs.twimg.com/media/HBYNI_naUAAxxpl.jpg?name=orig ; TX52 is LEFT ONLY.
- `references/terminal.jpg`:1758×1492 https://pbs.twimg.com/media/GMHr1DZaQAAV35B.jpg?name=orig . Clean lowercase i,l in Interval/local, although small and antialiased.

## Exact vector coverage
`#+-.012345678:ABCDEFGHILMNOPRSTUWXYZ▲▷` (38 characters).
No lowercase, digit9, J,K,Q,V in this vector. Digit9 exists in original announcement.
The exact supplied strings529741 and ilI1 were not found as independent official high-resolution assets. Existing banner resolves5,2,7,4,1,I precisely; raster sources supply9,i,l.

## Measurements
Flat cap height32.643 SVG units. Repeated cell pitch28.991 units. Their ratio0.888124; at cap700 the original cell is621.687, not604. JSON uses requested604 while centering ink and retaining exact outline dimensions. This does not preserve asymmetric source sidebearings. Flat vertical stem3.936=84.403 at cap700; horizontal stroke often3.840=82.345. Round overshoot0.480≈10.294.

| Glyph | width at cap700 | height at cap700 |
|---|---:|---:|
|0|471.470|720.608|
|5|417.946|700.256|
|2|446.788|710.293|
|7|428.239|700.000|
|4|463.214|710.293|
|1|290.289|700.000|
|I|351.040|699.979|
|O|486.910|720.586|
|M|500.291|700.000|

## Shape findings
1 has an angled flag and no baseline foot. I has short rectangular top/bottom bars. 4 has open top and steep diagonal. 7 has curved descending stroke and no middle crossbar. 0 is narrow rounded rectangle; O has more continuously oval sides and is wider (486.9 versus471.5 at cap700). 5 has a flat top and smooth lower bowl. Curves are true cubic Béziers, not rounded polyline substitutes.

Publicly visible specimen outlines do not establish a license to distribute a font made from those outlines. Source identity and extraction are recorded here for reference analysis, not as a license claim.
