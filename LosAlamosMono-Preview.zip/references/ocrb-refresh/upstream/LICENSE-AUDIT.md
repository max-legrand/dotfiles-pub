# OCR-B upstream license and provenance audit

Read-only research. Retrieved 2026-09-09T22:20:50.984933+00:00.
Repository: https://github.com/jaycee723/ocr-b
Pinned commit: `fedeba81519770109925b5bec70e940be5948d8f`.

## Downloaded artifact

`dist/OCR-B.otf` is the unmodified upstream binary (43,228 bytes).
SHA-256: `7b00732ad2312709d531158e8024b05e35b967bdfa5683abf601674415a71b86`.
The supplied raw-master path was fetched separately and is byte-identical to the
commit-pinned download. See `download-manifest.json` and
`raw-master-verification.json` for URLs and checksums.

Other original files retained here: `LICENSE.md`, `README.md`,
`OCR-B.ufo/fontinfo.plist`, `OCR-B.ufo/lib.plist`, and
`OCR-B.ufo/metainfo.plist`. These are reference copies, not edits to project font
sources or builds. GitHub API metadata and history are retained in the JSON files.

## Actual published license

`LICENSE.md:1-4` states:

> Copyright (c) 2019, Raisty (https://github.com/raisty),
> with Reserved Font Name OCR-B.
>
> This Font Software is licensed under the SIL Open Font License, Version 1.1.

The repository's GitHub license detection also reports `OFL-1.1`, but the actual
license file, not detection alone, is the evidence used here.

### Derivatives and glyph reuse

`LICENSE.md:49-52` grants permission to:

> use, study, copy, merge, embed, modify, redistribute, and sell modified and
> unmodified copies of the Font Software, subject to the following conditions

The definition at lines 40-43 includes adding, deleting, or substituting components
"in part or in whole". Copying lowercase and punctuation outlines into another
font is therefore covered by the published modification/merge permission, subject
to the conditions. It is not an exception from the font license just because only
a subset is copied.

### Rename and redistribution conditions

1. **No standalone sale of font software or components.** Condition 1, lines 54-55:
   "Neither the Font Software nor any of its individual components, in Original
   or Modified Versions, may be sold by itself."
2. **Retain copyright and full license with each redistributed copy.** Condition
   2, lines 57-62, allows bundling/distribution/sale with software, provided
   "each copy contains the above copyright notice and this license". Standalone
   text, readable headers, or easily viewed metadata can hold them. Supplying
   `LICENSE.md` is safer than relying on this original OTF's short `OFL` string.
3. **Do not use the reserved primary name for a derivative.** Condition 3, lines
   64-67: "No Modified Version ... may use the Reserved Font Name(s) unless
   explicit written permission is granted ... This restriction only applies to
   the primary font name as presented to the users." Here the reserved name is
   `OCR-B`. A distinctly named derivative is permitted without that permission.
   Upstream names can remain in attribution; the attribution is not branding.
4. **Do not imply author endorsement.** Condition 4, lines 69-73, prohibits using
   author/copyright-holder names to promote, endorse, or advertise a modified
   version except contribution acknowledgement or explicit written permission.
5. **Distribute the resulting modified font under OFL, not a conflicting license.**
   Condition 5, lines 75-79: "The Font Software, modified or unmodified, in part
   or in whole, must be distributed entirely under this license, and must not be
   distributed under any other license." This requirement does not apply to
   documents created using the font. It is not a license grant for unrelated
   third-party outlines merged into the derivative, nor a requirement to relicense
   all unrelated project software or documents.

The license also terminates when conditions are not met (lines 81-83). Its
disclaimer expressly disclaims warranties of noninfringement. Thus the existence
of an OFL notice must not be presented as a verified clean chain of title.

## Binary metadata inspection

Read with `uv run python` and the project's `fontTools.ttLib.TTFont`; no font
imports were made in the orchestration kernel. Full output is in
`font-metadata.json`.

- Name ID 0: `Copyright © Raisty`.
- Name IDs 1, 3, 4, 6: `OCR-B`.
- Name ID 2: `Regular`; ID 17: `Normal`.
- Name ID 5: `1.1`.
- Name ID 13 (license description): `OFL`.
- Name ID 14 (license URL): `https://scripts.sil.org/OFL`.
- CFF Copyright: `Copyright Copyright Raisty` (literal text in upstream binary).
- CFF FullName: `OCR-B Normal`; FamilyName: `OCR-B`; version: `1.1`.
- OS/2 `fsType` is 0 (no embedding restriction bits set). This bit field does not
  replace the license and does not prove authorship or ownership.
- Units per em: 1024; OpenType CFF outlines.

These fields agree with the repository's **stated** OFL licensing. The binary does
not carry the full license text or reserved-name declaration; retain the license
file alongside redistribution.

## Provenance limits

1. `README.md:3` states: "OCR-B is a monospace font originally developed in 1968 by
   Adrian Frutiger. This distribution brings many improvements." It gives no
   original outline source, rights assignment, earlier license, permission letter,
   or explanation of how the 1968 design became this digital font.
2. README CDN examples point to `raisty/OCR-B`. GitHub's public repository API
   returned `404`/`Not Found` for that repository during this audit. This is not
   proof of wrongdoing or even permanent deletion; it limits what could be
   verified from that link. Response retained in `raisty-github-repository.json`.
3. This repository's API reports `fork: false`. Its entire returned history has
   two commits: initial two-line README (`c9aa28d228ce57dc5fa07fd1b5a10e72eeb0c368`)
   and bulk "Initial OCR-B" import (`fedeba81519770109925b5bec70e940be5948d8f`). The import commit author is
   `Rastislav`; the license identifies `Raisty`. No earlier creation history is
   supplied here. See `github-commits.json`, `github-head-commit.json`, and
   `github-initial-commit.json`.
4. Source `OCR-B.ufo/fontinfo.plist` gives its top-level copyright as
   `Copyright © Raisty` and licensing as `OFL`, but its explicit historic
   `openTypeNameRecords` include `Copyright © Max` across several platforms and
   languages. Those records also have `OCR-B-original` and version `1.00`.
   The available documents do not explain who Max was or any transfer or relicensing
   rights. This discrepancy is a provenance question, not proof of infringement.
5. `lib.plist` contains only glyph order. `metainfo.plist` identifies the UFO
   creator as `org.robofab.ufoLib` and format version 3. Neither adds rights evidence.

## Decision guidance

**Conditional yes under the published OFL:** lowercase/punctuation reuse and
renaming are expressly permitted if all applicable license conditions are met.
Use a new primary font name, retain Raisty's notice and full OFL, acknowledge
upstream without implying endorsement, do not sell the font alone, and distribute
the derivative font under OFL.

**Not a verified rights-chain clearance:** the supplied repo and binary are
consistently labeled OFL, but underlying digital-outline provenance remains
unclear. Do not describe the complete historical chain as verified or as public
domain. For a release that needs strong legal clearance, obtain source/permission
confirmation from the publisher or use an independently documented alternative.

Starting a new font wholly from this OCR-B binary avoids importing other existing
font paths, but it does not resolve OCR-B's own provenance gap. Visual matching to
another proprietary design is not, by itself, proof of legal independence. This
audit does not evaluate the rights in the project's existing reference artwork.
